int led_red = 13;
int led_blue = 12;

int btn_red = 10;
int btn_blue = 11;

int bnt_state_red = 0;
int btn_state_blue = 0;

void setup() {
  // put your setup code here, to run once:
  pinMode(led_red, OUTPUT);
   pinMode(led_blue, OUTPUT);
  pinMode(btn_red,INPUT);


void loop() {
  // put your main code here, to run repeatedly:

}
